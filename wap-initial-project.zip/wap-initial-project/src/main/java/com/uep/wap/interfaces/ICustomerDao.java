package com.uep.wap.interfaces;

import com.uep.wap.model.Customer;

public interface ICustomerDao extends GenericDao<Customer, Integer> {
}
