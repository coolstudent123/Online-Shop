package com.uep.wap.interfaces;

import com.uep.wap.model.Order;

import java.time.LocalDate;
import java.util.List;

public interface IOrderDao extends GenericDao<Order, Integer> {
    List<Order> getSortOrders(String criterion);
    List<Order> getSortCompleteOrders(String criterion, LocalDate date);
}
